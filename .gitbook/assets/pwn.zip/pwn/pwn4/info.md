Find a way to pop a shell.
